#ifndef _usb_cdc_H
#define _usb_cdc_H


#include "stm32f4xx.h"
#include "usb_core.h"


#endif
