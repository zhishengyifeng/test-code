#ifndef _I2C_H
#define _I2C_H

#include "stm32f4xx.h"

void I2C_INIT(void);

#endif
