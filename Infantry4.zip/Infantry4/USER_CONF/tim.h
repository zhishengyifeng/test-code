#ifndef _tim_H
#define _tim_H


#include "stm32f4xx.h"


void TIM5_DEVICE(int per,int psc);
void TIM4_DEVICE(int per,int psc);
void TIM1_DEVICE(int per,int psc);
void TIM12_DEVICE(int per,int psc);
void TIM10_DEVICE(int per,int psc);
void TIM8_DEVICE(int per,int psc);


#endif

