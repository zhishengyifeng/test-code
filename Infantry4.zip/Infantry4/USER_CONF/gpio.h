#ifndef _gpio_H
#define _gpio_H

#include "stm32f4xx.h"


void GPIO_INIT(void);

extern uint8_t key_state;

#endif 


