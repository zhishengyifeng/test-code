#ifndef _usart_H
#define _usart_H

#include "stm32f4xx.h"


void USART1_DEVICE(void);
void USART3_DEVICE(void);
void USART6_DEVICE(void);
void USART8_DEVICE(void);

#endif 

