#ifndef _spi_H
#define _spi_H


#include "stm32f4xx.h"

void SPI_DEVICE(void);



#endif

