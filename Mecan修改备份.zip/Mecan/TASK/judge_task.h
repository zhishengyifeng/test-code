#ifndef _judge_task_H
#define _judge_task_H


#include "stm32f4xx.h"


void judge_tx_task(void *parm);
void judge_rx_task(void *parm);

#endif

